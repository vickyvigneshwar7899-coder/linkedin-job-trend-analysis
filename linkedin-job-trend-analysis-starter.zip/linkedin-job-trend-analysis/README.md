# LinkedIn Job Trend Analysis

## Objective
Analyze job postings to uncover **skill demand trends** across cities and roles. 
The project highlights which skills are most requested for each role and market, with clear visuals and a final Excel report.

## Deliverables
- Heatmap of **Top 10 Skills by City**
- **Skill vs Role** demand matrix
- Top overall skills bar chart
- City-wise job demand recommendations
- Excel report with all tables and visuals

## Tools
- Python: Pandas, Numpy, Matplotlib
- Excel
- Jupyter Notebook

## Project Structure
```
linkedin-job-trend-analysis/
├── data/
│   ├── sample_jobs_dataset.csv
│   └── outputs/
│       ├── sample_top_skills_by_city_heatmap.png
│       ├── sample_skill_vs_role_matrix.png
│       ├── sample_top_overall_skills.png
│       ├── sample_job_trend_analysis.xlsx
│       └── sample_job_demand_recommendations.txt
├── notebooks/
│   └── analysis.ipynb
├── scripts/
│   └── pipeline.py
├── README.md
├── requirements.txt
└── .gitignore
```

## Quick Start
1. Create a fresh environment and install requirements:
   ```bash
   pip install -r requirements.txt
   ```
2. Run the pipeline script (writes outputs to `data/outputs/`):
   ```bash
   python scripts/pipeline.py
   ```
3. Open the notebook for an interactive walkthrough:
   ```bash
   jupyter notebook notebooks/analysis.ipynb
   ```

## Sample Visuals
Top Skills by City:
![Top Skills by City](data/outputs/sample_top_skills_by_city_heatmap.png)

Skill vs Role Matrix:
![Skill vs Role Matrix](data/outputs/sample_skill_vs_role_matrix.png)

## Notes
- The repository includes a **sample dataset** for demonstration. 
- Replace `data/sample_jobs_dataset.csv` with your dataset using the same columns: `job_title, role, city, skills` (skills separated by commas or semicolons).

## Author
V ignesh
