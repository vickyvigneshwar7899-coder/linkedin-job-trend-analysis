import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime
import os

BASE_DIR = os.path.dirname(os.path.dirname(__file__))
DATA_PATH = os.path.join(BASE_DIR, "data", "sample_jobs_dataset.csv")
OUT_DIR = os.path.join(BASE_DIR, "data", "outputs")
os.makedirs(OUT_DIR, exist_ok=True)

def clean_split_skills(s):
    if pd.isna(s):
        return []
    parts = [p.strip() for chunk in str(s).split(";") for p in chunk.split(",")]
    norm = []
    for p in parts:
        p_low = p.lower()
        if p_low in {"tf","tensorflow"}:
            norm.append("TensorFlow")
        elif p_low in {"pytorch","torch"}:
            norm.append("PyTorch")
        elif p_low in {"ms excel","microsoft excel","excel"}:
            norm.append("Excel")
        elif p_low in {"machine learning","ml"}:
            norm.append("Machine Learning")
        elif p_low in {"nlp","natural language processing"}:
            norm.append("NLP")
        elif p_low in {"scikit","scikit learn","sklearn","scikit-learn"}:
            norm.append("Scikit-learn")
        else:
            norm.append(p.strip().title())
    norm = [x for x in norm if x]
    return norm

def main():
    df = pd.read_csv(DATA_PATH)
    df["skill_list"] = df["skills"].apply(clean_split_skills)
    skills_exploded = df.explode("skill_list").rename(columns={"skill_list":"skill"})
    skills_exploded = skills_exploded.dropna(subset=["skill"])

    # City-skill heatmap data
    city_skill_counts = (
        skills_exploded.groupby(["city","skill"], as_index=False).size()
        .rename(columns={"size":"count"})
    )
    top10_by_city = (
        city_skill_counts.sort_values(["city","count"], ascending=[True,False])
        .groupby("city", as_index=False)
        .head(10)
    )
    top_skills_union = sorted(top10_by_city["skill"].unique().tolist())
    heatmap_df = (
        city_skill_counts[city_skill_counts["skill"].isin(top_skills_union)]
        .pivot(index="city", columns="skill", values="count")
        .fillna(0)
        .astype(int)
        .sort_index()
    )

    # Plot heatmap
    plt.figure(figsize=(14,7))
    plt.imshow(heatmap_df.values, aspect="auto")
    plt.xticks(range(len(heatmap_df.columns)), heatmap_df.columns, rotation=45, ha="right")
    plt.yticks(range(len(heatmap_df.index)), heatmap_df.index)
    plt.colorbar(label="Postings mentioning skill")
    plt.title("Top Skills by City (Heatmap)")
    plt.tight_layout()
    heatmap_png = os.path.join(OUT_DIR, "sample_top_skills_by_city_heatmap.png")
    plt.savefig(heatmap_png, dpi=160)
    plt.close()

    # Skill vs Role matrix
    skill_role = (
        skills_exploded.groupby(["role","skill"], as_index=False).size()
        .rename(columns={"size":"count"})
    )
    skill_role_matrix = (
        skill_role.pivot(index="skill", columns="role", values="count")
        .fillna(0).astype(int).sort_index()
    )
    plt.figure(figsize=(14,9))
    plt.imshow(skill_role_matrix.values, aspect="auto")
    plt.xticks(range(len(skill_role_matrix.columns)), skill_role_matrix.columns, rotation=30, ha="right")
    plt.yticks(range(len(skill_role_matrix.index)), skill_role_matrix.index)
    plt.colorbar(label="Postings mentioning skill")
    plt.title("Skill vs Role Matrix")
    plt.tight_layout()
    skill_role_png = os.path.join(OUT_DIR, "sample_skill_vs_role_matrix.png")
    plt.savefig(skill_role_png, dpi=160)
    plt.close()

    # Top overall skills bar chart
    top_overall = (
        skills_exploded["skill"].value_counts().reset_index()
        .rename(columns={"index":"skill","skill":"count"})
    )
    topN = 20
    top_overall_n = top_overall.head(topN)
    plt.figure(figsize=(12,6))
    plt.bar(top_overall_n["skill"], top_overall_n["count"])
    plt.xticks(rotation=45, ha="right")
    plt.ylabel("Count")
    plt.title(f"Top {topN} Skills Across All Cities & Roles")
    plt.tight_layout()
    top_overall_png = os.path.join(OUT_DIR, "sample_top_overall_skills.png")
    plt.savefig(top_overall_png, dpi=160)
    plt.close()

    # Recommendations
    role_city_counts = df.groupby(["city","role"]).size().reset_index(name="count")
    top_role_per_city = role_city_counts.sort_values(["city","count"], ascending=[True,False]).groupby("city").head(1)

    recommendations = []
    for city in df["city"].unique():
        city_top_skills = (
            city_skill_counts[city_skill_counts["city"] == city]
            .sort_values("count", ascending=False)
            .head(5)[["skill","count"]]
            .to_records(index=False)
        )
        skill_list = [f"{s} ({c})" for s, c in city_top_skills]
        top_role_row = top_role_per_city[top_role_per_city["city"] == city]
        if not top_role_row.empty:
            top_role = top_role_row["role"].values[0]
            top_role_cnt = int(top_role_row["count"].values[0])
        else:
            top_role, top_role_cnt = "N/A", 0
        recommendations.append({
            "city": city,
            "top_hiring_role": f"{top_role} ({top_role_cnt})",
            "priority_skills_to_focus": ", ".join(skill_list)
        })
    reco_df = pd.DataFrame(recommendations)

    # Excel export
    excel_path = os.path.join(OUT_DIR, "sample_job_trend_analysis.xlsx")
    with pd.ExcelWriter(excel_path, engine="xlsxwriter") as writer:
        df.to_excel(writer, sheet_name="raw_jobs", index=False)
        skills_exploded.to_excel(writer, sheet_name="skills_exploded", index=False)
        heatmap_df.to_excel(writer, sheet_name="heatmap_city_skill")
        skill_role_matrix.to_excel(writer, sheet_name="skill_vs_role")
        top_overall_n.to_excel(writer, sheet_name="top_overall_skills", index=False)
        reco_df.to_excel(writer, sheet_name="recommendations", index=False)
        for sheet, img, cell in [
            ("heatmap_city_skill", heatmap_png, "J2"),
            ("skill_vs_role",     skill_role_png, "J2"),
            ("top_overall_skills", top_overall_png, "J2"),
        ]:
            try:
                writer.sheets[sheet].insert_image(cell, img)
            except Exception:
                pass

    # Recommendation text file
    reco_txt_path = os.path.join(OUT_DIR, "sample_job_demand_recommendations.txt")
    lines = ["Job Demand Recommendations (sample dataset)"]
    lines.append(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    lines.append("")
    for _, row in reco_df.iterrows():
        lines.append(f"- {row['city']}: focus on {row['priority_skills_to_focus']}; top hiring role: {row['top_hiring_role']}")
    with open(reco_txt_path, "w") as f:
        f.write("\n".join(lines))

if __name__ == "__main__":
    main()
